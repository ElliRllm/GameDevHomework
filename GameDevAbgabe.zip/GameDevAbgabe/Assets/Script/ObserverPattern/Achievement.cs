﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Achievement : Subject
{
    [SerializeField] private int achieved;
    private static int Counter;

    [SerializeField] private string AchievementName;



    private void Start()
    {
        RegisterObserver(GameObject.FindObjectOfType<AchievementSystem>());
    }

    private void OnTriggerEnter(Collider other)
    {
        Health objHealth = other.GetComponent<Health>();
        JuiceBox jbox = gameObject.GetComponent<JuiceBox>();


        if (jbox.vergZeit != null && objHealth != null)
        {
            if (jbox.vergZeit == 0 && objHealth.currentHealth < objHealth.maxHealth)
            {
                Counter++;
                Debug.Log("Achievement COUNTED");
                if (Counter == achieved)
                {
                    Notify(AchievementName, NotificationType.AchievementUnlocked);
                }
            }
        }
    }
}
