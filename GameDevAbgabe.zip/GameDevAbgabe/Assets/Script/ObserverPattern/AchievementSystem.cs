﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class AchievementSystem : Observer
{
    // Start is called before the first frame update
    void Start()
    {
        PlayerPrefs.DeleteAll();


    }

    public override void OnNotify(object value, NotificationType notificartiontype)
    {
        if (notificartiontype == NotificationType.AchievementUnlocked)
        {
            string achievmentKey = "achivement-" + value;

            if (PlayerPrefs.GetInt(achievmentKey) == 1)
                return;

            PlayerPrefs.SetInt(achievmentKey, 1);
            Debug.Log("Unlocked " + value);

        }
    }
}


public enum NotificationType
{
    AchievementUnlocked
}