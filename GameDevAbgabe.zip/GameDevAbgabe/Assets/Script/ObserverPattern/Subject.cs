﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Subject : MonoBehaviour
{
    private List<Observer> observerlist = new List<Observer>();

    public void RegisterObserver(Observer obs)
    {
        observerlist.Add(obs);
    }

    public void RemoveObserver(Observer obs)
    {
        observerlist.Remove(obs);
    }

    public void Notify(object value, NotificationType notificationType)
    {
        foreach (var observer in observerlist)
        {
            observer.OnNotify(value, notificationType);
        }
    }
}
