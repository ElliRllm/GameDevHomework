﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JuiceBox : MonoBehaviour
{

    [SerializeField] private int HealAmount;
    [SerializeField] private float Cooldown;

    public float vergZeit; //has to be public 
    private MeshRenderer objRenderer;
    private Collider objCollider;



    private void Awake()
    {
        objRenderer = gameObject.GetComponent<MeshRenderer>(); //fetching the MeshRenderer
        objCollider = gameObject.GetComponent<Collider>();  //fetching the Collider
    }




    private void OnTriggerEnter(Collider other)
    {
        GameObject obj = other.gameObject; //getting the GameObject that got DA JUICE


        if (obj.tag != "Player") // checking if the collided Object ist really an enemy - because ENEMYS GET NO JUICE!
        {
            return;
        }


        Health health = obj.GetComponent<Health>(); //getting the "Health" component so we can read the current Health / max Health


        if (health.currentHealth < health.maxHealth) //healing the player if neccessary
        {
            health.currentHealth += HealAmount;
            DisableTheJuice();

            health.OnChangeHealth(health.currentHealth); //updating the healthbar

        }

        if (health.currentHealth > health.maxHealth)  // to prevent "overhealing" we check again if the currentHealth exeeds the Maximum
        {
            health.currentHealth = health.maxHealth;
            DisableTheJuice();

            health.OnChangeHealth(health.currentHealth); //updating the healthbar

        }
    }



    private void Update()
    {
        if (objRenderer.enabled == false)  //count up the Time the Juice box is not Rendered -> Disabled
        {
            vergZeit += Time.deltaTime;


            if (vergZeit >= Cooldown) //Respawn JUICE after the Countdown
            {
                EnableTheJuice();

                vergZeit = 0;
            }

        }
    }


    private void DisableTheJuice() //makes the Juice invisible and disables the collider/trigger   -- DISABLE
    {
        objRenderer.enabled = false;
        objCollider.enabled = false;
    }

    private void EnableTheJuice() //makes the Juice visible and enables the collider/trigger   -- ENABLE
    {
        objRenderer.enabled = true;
        objCollider.enabled = true;
    }



}
