﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;



public class Health : NetworkBehaviour
{
    public int maxHealth;
    //[SyncVar (hook = "OnChangeHealth")]   ~ein hook wäre viel eleganter und einfacher allerdings hat es einfach nicht funktionieren wollen also rufen nun sowohl die "Bullets" als auch die "Juice Boxes" selbst die "OnChangeHealth" Funktion auf
    public int currentHealth;
    public RectTransform healthbar;

    public void Awake()
    {
        currentHealth = maxHealth;
    }


    //[Command]
    //public void CmdTakeDamage(int dmg)
    //{
    //    Debug.Log("cmddmg AUFGERUFEN"); //wird nicht aufgerufen :/
    //        RpcTakeDamage(dmg);
    //}

    //[ClientRpc]
    //public void RpcTakeDamage(int dmg)
    //{
    //    Debug.Log("rpcdmg AUFGERUFEN"); //das schon gar nicht ...
    //    currentHealth -= dmg;
    //    Debug.Log("damage wurde berechnet...");
    //    if (currentHealth <= 0)
    //    {
    //        switch (gameObject.tag)
    //        {
    //            case "Player":
    //                currentHealth = 0;
    //                Debug.Log(gameObject.name + " died");

    //                gameObject.SetActive(false);


    //                break;

    //            case "Enemy":
    //                Debug.Log("ENEMY DEAD"); 
    //                currentHealth = 0;

    //                ObjPooler.poolDictionary[gameObject.tag].Enqueue(gameObject);
    //                gameObject.SetActive(false);

    //                break;
    //        }


    //    }

    //    OnChangeHealth(currentHealth);

    //}


    public void Takedmg(int dmg)
    {
        currentHealth -= dmg;
        Debug.Log("damage wurde berechnet...");
        if (currentHealth <= 0)
        {
            switch (gameObject.tag)
            {
                case "Player":
                    currentHealth = 0;


                    if (isLocalPlayer)
                    {
                        //GameObject.Find("DeadText").GetComponent<Text>().text = gameObject.name + " died :(";
                        GameObject.Find("DeadText").GetComponent<Text>().text = gameObject.name + " survived for " + Time.realtimeSinceStartup + " wonderful Moments";
                        GameObject.Find("deadCanvas").GetComponent<Canvas>().enabled = true;
                    }


                    Debug.Log(gameObject.name + " died");

                    gameObject.SetActive(false);

                    break;

                case "Enemy":
                    Debug.Log("ENEMY DEAD");
                    currentHealth = 0;

                    NetworkServer.Destroy(gameObject);

                   // ObjPooler.poolDictionary[gameObject.tag].Enqueue(gameObject);
                   // gameObject.SetActive(false);

                    break;
            }
        }


        OnChangeHealth(currentHealth);
    }

    //[ClientRpc]
    //public void RpcDeadScreen()
    //{
    //}

    public void OnChangeHealth(int health)
    {
        Debug.Log("CHANGEHEALTH AUFGERUFEN");
        healthbar.sizeDelta = new Vector2(health * 2, healthbar.sizeDelta.y);
    }
}
