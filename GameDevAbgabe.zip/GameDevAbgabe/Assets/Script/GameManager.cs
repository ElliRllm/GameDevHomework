﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class GameManager : MonoBehaviour


{
    public static GameManager Instance;

    public List<GameObject> playerGameObjList;

    public List<PlayerID> playerList;
    public NetworkManager nManager;


    // Start is called before the first frame update
    void Start()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(this);
        }

    }
}