﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class ObjPooler : MonoBehaviour
{
    [Serializable]
    public class Pool
    {
        public string tag;
        public GameObject prefab;
        public int size;
    }

    public static ObjPooler Instance;
    public List<Pool> pools;
    public static Dictionary<string, Queue<GameObject>> poolDictionary;



    private void Awake()        //checks if there already is an ObjectPooler
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }


    private void Start()
    {
        poolDictionary = new Dictionary<string, Queue<GameObject>>();       //creats a Dictionary of which will be filled with the Pool Names and their respective Queues

        foreach (Pool pool in pools)        // creates the amount of Pools given in the Inspector..
        {
            Queue<GameObject> objectPool = new Queue<GameObject>();


            for (int i = 0; i < pool.size; i++)     //..and fills them with the given Prefab while enqueueing and deactivating them
            {
                GameObject obj = Instantiate(pool.prefab);

                obj.SetActive(false);
                objectPool.Enqueue(obj);
            }

            poolDictionary.Add(pool.tag, objectPool);       //adds the pools/queues to the dictionary
        }
    }

    public GameObject SpawnFromPool(string tag, Vector3 pos, Quaternion rot)        //takes the first object in the given pool (tag) and activates it at the given position/rotation + setzt sie wieder hinten in die queue
    {
        if (!poolDictionary.ContainsKey(tag))       //checks if the given tag is in our pool Dictionary
        {
            print("no such tag in Object pooler");
            return null;
        }

        GameObject obj = poolDictionary[tag].Dequeue();

        obj.SetActive(true);
        obj.transform.position = pos;
        obj.transform.rotation = rot;


        poolDictionary[tag].Enqueue(obj);       //ENQUEUED 
        return obj;
    }

    //************************************************************************** - is similar to "SpawnFromPool" but DOES NOT ENQUEUE spawned entitys - to prevent enemies from Respawning without beeing defeated first  
    public GameObject SpawnEFromPool(string tag, Vector3 pos, Quaternion rot)
    {
        if (!poolDictionary.ContainsKey(tag))
        {
            print("no such tag in Object pooler");
            return null;
        }

        if (poolDictionary[tag].Count > 0)
        {
            GameObject obj = poolDictionary[tag].Dequeue();

            obj.SetActive(true);
            obj.transform.position = pos;
            obj.transform.rotation = rot;


            return obj;
        }
        else
        {
            return null;
        }
    }

    public static void RePool(string tag, GameObject obj)
    {
        poolDictionary[tag].Enqueue(obj);
    }
    //*************************************************************************
}