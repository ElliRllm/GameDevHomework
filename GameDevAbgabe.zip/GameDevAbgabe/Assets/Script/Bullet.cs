﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class Bullet : NetworkBehaviour
{
    public int speed;

    public int damage;

    // Update is called once per frame and moves the bullet 
    void Update()
    {
        transform.position += transform.forward * speed * Time.deltaTime;
    }


    public void OnCollisionEnter(Collision collision)
    {
        GameObject hit = collision.gameObject;
        Health health = hit.GetComponent<Health>();

        if (health == null)
            return;


        health.Takedmg(damage);

        gameObject.SetActive(false);

    }









    //----------------------------------------------------------------------------------------------------------------------------------------------------------
    //public void OnCollisionEnter(Collision other)
    //{
    //    GameObject obj = other.gameObject;
    //    String tag = obj.tag;

    //    Breakable destroyObj = other.gameObject.GetComponent<Breakable>();
    //    if (destroyObj != null)
    //    {
    //        print("found destroyable");
    //        destroyObj.health -= damage;
    //        if (destroyObj.health <= 0)
    //        {
    //            destroyObj.Explode(tag, obj);
    //            print("ouch");
    //        }


    //        gameObject.SetActive(false);
    //        print("peng");

    //    }

    //}

    //----------------------------------------------------------------------------------------------------------------------------------------------------------
}

