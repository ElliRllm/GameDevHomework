﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IState   //definiert was ein State ausmacht 
{
    void Enter();
    void Execute();
    void Reason();
    void Exit();
}
