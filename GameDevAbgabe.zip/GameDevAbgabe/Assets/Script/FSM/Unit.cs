﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Unit : MonoBehaviour
{
    //public float UnitSpeed;
    public float ShootingDistance;
    public float delay;

    public Transform shootPos;

    public StateMachine stateMachine = new StateMachine();

    public GameObject[] playerArray;
    public NavMeshAgent agent;


    void Start()
    {
        stateMachine.ChangeState(new StateChase(this));


        agent = GetComponent<NavMeshAgent>();

        playerArray = GameManager.Instance.playerGameObjList.ToArray();
    }

    void Update()
    {
        stateMachine.Update();
    }
}
