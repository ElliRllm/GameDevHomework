﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class StateAttack : NetworkBehaviour, IState
{
    Unit owner;
    private float delayTime;

    public StateAttack(Unit owner) { this.owner = owner; }

    public void Enter()
    {
        Debug.Log("entering Attack state");

        // owner.agent.speed = 0;
    }

    public void Execute()
    {
        //    if (isLocalPlayer)
        //    {
        delayTime += Time.deltaTime;

        if (delayTime > owner.delay)
        {
            delayTime = 0;
            EnemyShoot();

        }
        // }


        Reason();


        Debug.Log("updating Attack state");
    }

    public void Reason()
    {
        if (owner.agent.remainingDistance > owner.ShootingDistance)
        {
            Debug.Log("HES GETTING OUT OF RANGE");
            owner.stateMachine.ChangeState(new StateChase(owner));
        }
        Debug.Log("Thinking");
    }

    public void Exit()
    {
        // owner.agent.speed = owner.UnitSpeed;

        Debug.Log("exiting Attack state");
    }




    private void EnemyShoot()
    {

        ObjPooler.Instance.SpawnFromPool("EnemyBullet", owner.shootPos.position, owner.shootPos.rotation);

        //    if (isServer)
        //        RpcEnemyShoot();
        //    else if (isClient)
        //    {
        //        ObjPooler.Instance.SpawnFromPool("EnemyBullet", owner.shootPos.position, owner.shootPos.rotation);

        //        CmdEnemyShoot();
        //    }

        //}

        //[Command]
        //public void CmdEnemyShoot()
        //{
        //    ObjPooler.Instance.SpawnFromPool("EnemyBullet", owner.shootPos.position, owner.shootPos.rotation);
        //}

        //[ClientRpc]
        //public void RpcEnemyShoot()
        //{
        //    ObjPooler.Instance.SpawnFromPool("EnemyBullet", owner.shootPos.position, owner.shootPos.rotation);
    }

}
