﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StateMachine
{
    private IState currentState;

    public void ChangeState(IState newState)    //changes the State while first calling oldState.EXIT and newState.ENTER
    {
        if (currentState != null)
            currentState.Exit();

        currentState = newState;
        currentState.Enter();
    }

    public void Update()        //calls vital State functions (Execute, Reason)
    {
        if (currentState != null)
        {
            currentState.Execute();
        }
    }
}
