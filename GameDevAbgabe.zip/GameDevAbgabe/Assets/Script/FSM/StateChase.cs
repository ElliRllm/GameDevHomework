﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StateChase : MonoBehaviour, IState
{
    Unit owner;
    private Dictionary<PlayerID, float> PlyDistanceDict = new Dictionary<PlayerID, float>();

    public StateChase(Unit owner) { this.owner = owner; }

    public int indexOfPlayer;


    public void Enter()
    {
        Debug.Log("entering Chase state");
    }

    public void Execute()
    {


        Transform Target = GetClosestPlayer(owner.playerArray);

        var TargetDirection = Target.position - owner.transform.position;
        owner.transform.rotation = Quaternion.LookRotation(TargetDirection);


        owner.agent.SetDestination(Target.position);

        Debug.Log("ENEMY FOUND");

        Debug.Log("updating Chase state");



        Reason();
    }

    public void Reason()
    {
        if (owner.agent.remainingDistance <= owner.ShootingDistance)
            owner.stateMachine.ChangeState(new StateAttack(owner));
    }


    public void Exit()
    {
        Debug.Log("exiting Chase state");
    }

    //***************************

    private Transform GetClosestPlayer(GameObject[] objPlayers)
    {
        Vector3 currentPosition = owner.transform.position;
        Transform minTrans = null;
        float minDist = Mathf.Infinity;

        for (int i = 0; i < objPlayers.Length; i++)
        {
            float dist = Vector3.Distance(objPlayers[i].transform.position, currentPosition);

            if (dist < minDist)
            {
                minTrans = objPlayers[i].transform;
                minDist = dist;
                indexOfPlayer = i;
            }
        }

        return minTrans;

    }



}
