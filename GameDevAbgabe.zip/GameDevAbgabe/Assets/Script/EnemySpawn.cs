﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class EnemySpawn : NetworkBehaviour
{


    public float gap;


    private float gapCount;

    public GameObject enemyType;
    public Transform spawnPos;

    // Update is called once per frame
    void Update()
    {
        if (isServer)
        {
            gapCount += Time.deltaTime;
            if (gapCount >= gap)
            {

                ESpawn();
                gapCount = 0;

            }
        }
    }

    public void ESpawn()
    {
        GameObject objEnemy = Instantiate(enemyType);
        NetworkServer.Spawn(objEnemy);

        objEnemy.transform.position = spawnPos.position;







        //if (isServer)
        //    RpcESpawn();
        //else if (isClient)
        //{
        //    ObjPooler.Instance.SpawnEFromPool("Enemy", spawnPos.position, spawnPos.rotation);
        //    //  health = BaseHealth;

        //    CmdESpawn();

        //}

    }

    [Command]
    public void CmdESpawn()
    {
        ObjPooler.Instance.SpawnEFromPool("Enemy", spawnPos.position, spawnPos.rotation);
        //        NetworkServer.Spawn(obj);
        //   health = BaseHealth;
    }

    [ClientRpc]
    public void RpcESpawn()
    {
        ObjPooler.Instance.SpawnEFromPool("Enemy", spawnPos.position, spawnPos.rotation);
        // health = BaseHealth;
    }
}
