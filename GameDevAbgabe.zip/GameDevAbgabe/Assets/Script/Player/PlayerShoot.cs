﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.Networking;
using UnityEngine;

public class PlayerShoot : NetworkBehaviour
{
    [SerializeField] Transform shootPos;
    [SerializeField] private float delay;

    private float delayCount;

    // Update is called once per frame
    void Update()
    {
        if (isLocalPlayer)
        {
            delayCount += Time.deltaTime;
            if (delayCount > delay)
            {
                if (Input.GetAxis("Fire1") > 0.1)
                {
                    delayCount = 0;
                    Shoot();
                }
            }
        }
    }

    public void Shoot()
    {
        if (isServer)
            RpcShoot();
        else if (isClient)
        {
            ObjPooler.Instance.SpawnFromPool("Bullet", shootPos.position, shootPos.rotation);

            CmdShoot();
        }

    }

    [Command]
    public void CmdShoot()
    {
        ObjPooler.Instance.SpawnFromPool("Bullet", shootPos.position, shootPos.rotation);
    }

    [ClientRpc]
    public void RpcShoot()
    {
        ObjPooler.Instance.SpawnFromPool("Bullet", shootPos.position, shootPos.rotation);
    }
}