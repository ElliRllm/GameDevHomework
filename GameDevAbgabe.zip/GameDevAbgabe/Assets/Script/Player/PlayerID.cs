﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class PlayerID : NetworkBehaviour
{
    [SyncVar] private string PlayerUniqueID;
    private NetworkInstanceId PlayerNetID;
    private Transform myTransform;

    public override void OnStartLocalPlayer()
    {
        GetNetworkID();
        SetID();
    }

    void Awake()
    {
        myTransform = transform;
    }

    void Start()
    {
        {
            GameManager.Instance.playerList.Add(this);
            GameManager.Instance.playerGameObjList.Add(this.gameObject);
            Debug.Log("a List is made");

        }
    }

    void Update()
    {
        if (myTransform.name == "" || myTransform.name == "Car_4(Clone)")
        {
            SetID();
            Debug.Log("IDs for everyone");
        }

        foreach (PlayerID plyID in GameManager.Instance.playerList)

            Debug.Log(GameManager.Instance.playerList);
    }




    [Client]
    private void GetNetworkID()
    {
        PlayerNetID = GetComponent<NetworkIdentity>().netId;
        CmdTellServerMyIdentity(MakeUniqueIdentity());
    }


    void SetID()
    {
        if (!isLocalPlayer)
        {
            myTransform.name = PlayerUniqueID;
        }
        else
        {
            myTransform.name = MakeUniqueIdentity();
        }
    }




    private string MakeUniqueIdentity()
    {
        string uniqueName = "Player " + PlayerNetID.ToString();
        return uniqueName;
    }

    [Command]
    void CmdTellServerMyIdentity(string name)
    {
        PlayerUniqueID = name;
    }



}
