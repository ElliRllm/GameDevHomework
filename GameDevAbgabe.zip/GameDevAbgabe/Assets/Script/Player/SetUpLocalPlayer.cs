﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using Cinemachine;

public class SetUpLocalPlayer : NetworkBehaviour
{

    private CinemachineVirtualCamera Camera;

    //  Start is called before the first frame update
    void Start()
    {
        if (isLocalPlayer)
        {
            GetComponent<PlayerMove>().enabled = true;      //only enabeling the movement for the local player and his character


            Camera = GameObject.FindObjectOfType<CinemachineVirtualCamera>(); //getting the Camera GameObject
            Camera.m_Follow = gameObject.transform;     //..and attaching it to the Player
        }
    }
}